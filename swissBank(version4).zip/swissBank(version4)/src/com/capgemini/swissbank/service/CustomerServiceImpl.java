package com.capgemini.swissbank.service;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.swissbank.bean.AccMasterBean;
import com.capgemini.swissbank.bean.CustomerBean;
import com.capgemini.swissbank.bean.PayeeBean;
import com.capgemini.swissbank.bean.TransactionBean;
import com.capgemini.swissbank.bean.UserTable;
import com.capgemini.swissbank.dao.CustomerDaoImpl;
import com.capgemini.swissbank.dao.ICustomerDao;
import com.capgemini.swissbank.exception.BankException;

public class CustomerServiceImpl implements ICustomerService {
	
	
	ICustomerDao customerDao = new CustomerDaoImpl();

	@Override
	public UserTable validateUser(int userId, String password)
			throws BankException {
		
		UserTable userTable= new UserTable();
		userTable=customerDao.validateUser(userId, password);
		return userTable;
	}

	@Override
	public List<TransactionBean> viewMiniStatement(int accountId)
			throws BankException {
		List<TransactionBean> list = customerDao.viewMiniStatement(accountId);
		return list;
	}

	@Override
	public List<TransactionBean> viewDetailedStatement(int accountId)
			throws BankException {
		List<TransactionBean> list= customerDao.viewDetailedStatement(accountId);
		return list;
	}

	@Override
	public boolean changePassword(int accountId, String oldPassword,
			String newPassword) throws BankException {
		
		return customerDao.changePassword(accountId, oldPassword, newPassword);
	}

	@Override
	public boolean changeAddress(int accountId, String address)
			throws BankException {
		
		return customerDao.changeAddress(accountId, address);
	}

	@Override
	public boolean changePhoneNumber(int accountId, String phoneNumber)
			throws BankException {
		
		return customerDao.changePhoneNumber(accountId, phoneNumber);
	}

	@Override
	public double inFundTransfer(int accountIdTo, int accountIdFrom,
			double transactionAmount) throws BankException {
		
	
		return customerDao.inFundTransfer(accountIdTo, accountIdFrom, transactionAmount);
	}

	@Override
	public boolean insertPayee(int accountId, int payeeAccountId,
			String nickName) throws BankException {
		
		return customerDao.insertPayee(accountId, payeeAccountId, nickName);
	}

	@Override
	public double outFundTransfer(int accountId, int payeeAccountId,
			String transactionPassword, double transactionAmount)
			throws BankException {
		return customerDao.outFundTransfer(accountId, payeeAccountId, transactionPassword, transactionAmount);
	}

	@Override
	public int generateCheque(int accountId) throws BankException {
		
		return customerDao.generateCheque(accountId);
	}

	@Override
	public String trackStatus(int requisitionId) throws BankException {
		
		return customerDao.trackStatus(requisitionId);
	}
	
/*	public List<String> isValidated(CustomerBean customerBean,AccMasterBean accMasterBean) {
		List<String> errorList = new ArrayList<String>();

		Pattern pattern = null;
		Matcher matcher = null;

		

		// Phone Number Validation
		pattern = Pattern.compile("^[7-9]{1}[0-9]{9}");
		matcher = pattern.matcher(customerBean.getPhoneNumber());
		if (!matcher.matches()) {
			errorList.add("Please enter a valid Phone Number");
		}

		// Address Validation
		pattern = Pattern.compile("^[A-Za-z0-9\\s,./]{3,}$");
		matcher = pattern.matcher(customerBean.getAddress());
		if (!matcher.matches()) {
			errorList.add("Please enter a valid Address");
		}
		
		//e-mail Validation
		pattern = Pattern.compile("\\b[A-Z0-9._%-]+@[A-Z0-9.-]+\\.[A-Z]{2,4}\\b");
		matcher = pattern.matcher(customerBean.getEmail());

		if (!matcher.matches()) {
			errorList.add("Please enter a valid Email Id");
		}
		// Amount Validation
		if (accMasterBean.getAccBalance()<3000) {
			errorList.add("Minimum balance should be 3000");
		}
		
		 
		
		return errorList;
	}*/
	
	
	@Override
	public List<PayeeBean> viewPayee(int accountId) throws BankException {
		
		return customerDao.viewPayee(accountId);
	}
	public boolean validateTransactionPassword(String transactionPassword,UserTable user){
		if(transactionPassword.equals(user.getTransPassword()))
			return true;
		else return false;
	}

	public boolean validateTransactionAmount(double transactionAmount){
		if(transactionAmount<1000000)
			return true;
		else return false;
	}

	@Override
	public boolean updateLockStatus(int userId) throws BankException {
		
		return customerDao.updateLockStatus(userId);
	}

	@Override
	public boolean validateUser(int userId) throws BankException {
				
		UserTable user=customerDao.validateUser(userId);
		if(user==null)
			return false;
		else return true;
	}
	
	
	public boolean getUserStatus(int userId)throws BankException
	{
		
	String staus=customerDao.getLockStatus(userId);
		if(staus.equals("o")){
			return true;
		}
		else
		return false;
	}

	@Override
	public String[] getSecretQuestion(int userId) throws BankException {	
		
		return customerDao.getSecretQuestion(userId);
	}

	@Override
	public boolean changePassword(int userId, String newPassword)
			throws BankException {
		
		return customerDao.changePassword(userId, newPassword);
	}

	
}
