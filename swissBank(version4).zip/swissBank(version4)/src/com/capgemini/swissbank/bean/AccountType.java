package com.capgemini.swissbank.bean;

public enum AccountType {
	Current, Savings;

}
