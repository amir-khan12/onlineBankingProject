package com.capgemini.swissbank.service;

import java.util.List;

import com.capgemini.swissbank.bean.AccMasterBean;
import com.capgemini.swissbank.bean.CustomerBean;
import com.capgemini.swissbank.bean.TransactionBean;
import com.capgemini.swissbank.bean.UserTable;
import com.capgemini.swissbank.dao.AdminDaoImpl;
import com.capgemini.swissbank.dao.IAdminDao;
import com.capgemini.swissbank.exception.BankException;

public class AdminServiceImpl implements IAdminService {
	
	IAdminDao adminDao= new AdminDaoImpl();

	@Override
	public UserTable createUser(AccMasterBean accMasterBean,
			CustomerBean customerBean) throws BankException {
		UserTable userTable= new UserTable();
		userTable=adminDao.createUser(accMasterBean, customerBean);
		return userTable;
	}

	@Override
	public List<TransactionBean> getTransactions(int choice)
			throws BankException {
		List<TransactionBean> list = adminDao.getTransactions(choice);
		return list;
	}

	@Override
	public List<TransactionBean> getTransactionsDaily() throws BankException {
		
		return adminDao.getTransactions(1);
	}

	@Override
	public List<TransactionBean> getTransactionsWeekly() throws BankException {
		// TODO Auto-generated method stub
		return adminDao.getTransactions(2);
	}

	@Override
	public List<TransactionBean> getTransactionsMonthly() throws BankException {
		// TODO Auto-generated method stub
		return adminDao.getTransactions(3);
	}
	
	


}
