package com.capgemini.swissbank.bean;

public class UserTable {
	private int accId;
	private int userId;
	private String userName;
	private String password;
	private String secretQue;
	private String secretAns;
	public String getSecretAns() {
		return secretAns;
	}
	public void setSecretAns(String secretAns) {
		this.secretAns = secretAns;
	}
	private String transPassword;
	private String lockStatus;
	private String type;
	public int getAccId() {
		return accId;
	}
	public void setAccId(int accId) {
		this.accId = accId;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getSecretQue() {
		return secretQue;
	}
	public void setSecretQue(String secretQue) {
		this.secretQue = secretQue;
	}
	public String getTransPassword() {
		return transPassword;
	}
	public void setTransPassword(String transPassword) {
		this.transPassword = transPassword;
	}
	public String getLockStatus() {
		return lockStatus;
	}
	public void setLockStatus(String lockStatus) {
		this.lockStatus = lockStatus;
	}

	public UserTable() {
		super();
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public UserTable(int accId, int userId, String userName, String password,
			String secretQue, String secretAns, String transPassword,
			String lockStatus, String type) {
		super();
		this.accId = accId;
		this.userId = userId;
		this.userName = userName;
		this.password = password;
		this.secretQue = secretQue;
		this.secretAns = secretAns;
		this.transPassword = transPassword;
		this.lockStatus = lockStatus;
		this.type = type;
	}
	@Override
	public String toString() {
		return "UserTable [accId=" + accId + ", userId=" + userId
				+ ", userName=" + userName + ", password=" + password
				+ ", secretQue=" + secretQue + ", secretAns=" + secretAns
				+ ", transPassword=" + transPassword + ", lockStatus="
				+ lockStatus + ", type=" + type + "]";
	}
	
	
}
