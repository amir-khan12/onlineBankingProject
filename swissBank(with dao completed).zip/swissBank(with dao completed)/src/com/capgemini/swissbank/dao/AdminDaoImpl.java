package com.capgemini.swissbank.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.capgemini.swissbank.bean.AccMasterBean;
import com.capgemini.swissbank.bean.CustomerBean;
import com.capgemini.swissbank.bean.TransactionBean;
import com.capgemini.swissbank.bean.UserTable;
import com.capgemini.swissbank.exception.BankException;
import com.capgemini.swissbank.util.DBConnection;

public class AdminDaoImpl implements IAdminDao {

	@Override
	public UserTable createUser(AccMasterBean accMasterBean,
			CustomerBean customerBean) throws BankException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<TransactionBean> getTransactions(int choice)
			throws BankException {
	
		
			int transactionNumber=0;
			List<TransactionBean> transactionList=new ArrayList<TransactionBean>();
			try{Connection conn=DBConnection.getInstance().getConnection();
			
			ResultSet rs=null;
			PreparedStatement preparedStatement=null;
					
			
				if(choice==1)
					preparedStatement=conn.prepareStatement(IQueryMapperAdmin.VIEWTRANSACTIONDAILY);
				else if(choice==2)
					preparedStatement=conn.prepareStatement(IQueryMapperAdmin.VIEWTRANSACTIONWEEKLY);	
				else if(choice==3)
					preparedStatement=conn.prepareStatement(IQueryMapperAdmin.VIEWTRANSACTIONMONTHLY);
				else
					return null;
				rs=preparedStatement.executeQuery();
				
				while(rs.next())
				{
					TransactionBean bean=new TransactionBean();
					bean.setAccId(rs.getInt(1));
					bean.setDateOfTrans(rs.getDate(2));
					bean.setTransDescription(rs.getString(3));
					bean.setTransId(rs.getInt(4));
					bean.setTransType(rs.getString(5));
					bean.setTransactionAmount(rs.getDouble(6));
					
					transactionList.add(bean);
					transactionNumber++;
				
				}
			} catch(SQLException sqlEx)
			{
				throw new BankException(sqlEx.getMessage());
			} catch (Exception e) {
				// TODO Auto-generated catch block
				throw new BankException(e.getMessage());
			}	
			if(transactionNumber == 0)
				return null;
			else
				return transactionList;
			
		}
		
	}


