package com.capgemini.swissbank.bean;

public class CustomerBean {
	private int accId;
	private String email;
	private String address;
	private String panNUm;
	private String phoneNumber;
	public CustomerBean() {
		super();
	}
	
	public CustomerBean(int accId, String email, String address, String panNUm,
			String phoneNumber) {
		super();
		this.accId = accId;
		this.email = email;
		this.address = address;
		this.panNUm = panNUm;
		this.phoneNumber = phoneNumber;
	}

	public int getAccId() {
		return accId;
	}
	public void setAccId(int accId) {
		this.accId = accId;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getPanNUm() {
		return panNUm;
	}
	public void setPanNUm(String panNUm) {
		this.panNUm = panNUm;
	}
	
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	@Override
	public String toString() {
		return "CustomerBean [accId=" + accId + ", email=" + email
				+ ", address=" + address + ", panNUm=" + panNUm
				+ ", phoneNumber=" + phoneNumber + "]";
	}
	
	
	
}
