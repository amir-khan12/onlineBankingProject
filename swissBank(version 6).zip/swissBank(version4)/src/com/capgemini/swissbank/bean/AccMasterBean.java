package com.capgemini.swissbank.bean;

import java.time.LocalDate;
import java.util.Date;

public class AccMasterBean {
	private int accId;
	private AccountType type;
	private double accBalance;
	private LocalDate openDate;
	public AccMasterBean() {
		super();
	}
	
	public int getAccId() {
		return accId;
	}
	public void setAccId(int accId) {
		this.accId = accId;
	}
	public AccountType getType() {
		return type;
	}
	public void setType(AccountType type) {
		this.type = type;
	}
	public double getAccBalance() {
		return accBalance;
	}
	public void setAccBalance(double accBalance) {
		this.accBalance = accBalance;
	}

	

	
	public LocalDate getOpenDate() {
		return openDate;
	}

	public void setOpenDate(LocalDate openDate) {
		this.openDate = openDate;
	}

	
	
	public AccMasterBean(int accId, AccountType type, double accBalance,
			LocalDate openDate) {
		super();
		this.accId = accId;
		this.type = type;
		this.accBalance = accBalance;
		this.openDate = openDate;
	}

	@Override
	public String toString() {
		return "AccMasterBean [accId=" + accId + ", type=" + type
				+ ", accBalance=" + accBalance + ", openDate=" + openDate
				+ "]";
	}
	
	
	

}
