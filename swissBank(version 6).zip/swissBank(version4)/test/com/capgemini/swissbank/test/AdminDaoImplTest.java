package com.capgemini.swissbank.test;

import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

import com.capgemini.swissbank.bean.AccMasterBean;
import com.capgemini.swissbank.bean.CustomerBean;
import com.capgemini.swissbank.bean.UserTable;
import com.capgemini.swissbank.dao.AdminDaoImpl;
import com.capgemini.swissbank.dao.IAdminDao;
import com.capgemini.swissbank.exception.BankException;

public class AdminDaoImplTest {

	static IAdminDao adminDao;
	static CustomerBean customerBean;
	static AccMasterBean accMasterBean;
	static UserTable user;
	
	@BeforeClass
	public static void initialize() throws Exception {
		adminDao=new AdminDaoImpl();
		customerBean = new CustomerBean();
		accMasterBean=new AccMasterBean();
		user=new UserTable();
	}

	@Test
	public void testCreateUser() throws BankException {
		Assert.assertNotNull(adminDao.createUser(accMasterBean, user,customerBean));
	}

	@Test
	public void testGetTransactions() {
		Assert.assertNotNull(1);
	}

}
