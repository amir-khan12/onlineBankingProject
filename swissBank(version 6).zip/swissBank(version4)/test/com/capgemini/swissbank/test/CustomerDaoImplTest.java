package com.capgemini.swissbank.test;

import org.junit.BeforeClass;
import org.junit.Test;

import com.capgemini.swissbank.bean.CustomerBean;
import com.capgemini.swissbank.dao.CustomerDaoImpl;
import com.capgemini.swissbank.dao.ICustomerDao;
import com.capgemini.swissbank.exception.BankException;

import junit.framework.Assert;

public class CustomerDaoImplTest {

	static ICustomerDao customerDao;
	static CustomerBean customerBean;
	
	@BeforeClass
	public static void initialize() {
		customerDao = new CustomerDaoImpl();
		customerBean = new CustomerBean();
	}
	
	@Test
	public void testValidateUserIntString() throws BankException {
		Assert.assertNotNull(customerDao.validateUser(10, "sbq500#"));
	}

	@Test
	public void testViewMiniStatement() throws BankException {
		Assert.assertNotNull(customerDao.viewMiniStatement(10001));
	}

	@Test
	public void testViewDetailedStatement() throws BankException {
		Assert.assertNotNull(customerDao.viewDetailedStatement(10001));
	}

	@Test
	public void testChangePasswordIntStringString() throws BankException {
		Assert.assertTrue(customerDao.changePassword(10, "sbq500#","abc"));
	}

	@Test
	public void testChangeAddress() throws BankException {
		Assert.assertTrue(customerDao.changeAddress(10001, "Kolkata"));
	}

	@Test
	public void testChangePhoneNumber() throws BankException {
		Assert.assertTrue(customerDao.changePhoneNumber(10001, "9876543210"));
	}

	@Test
	public void testInFundTransfer() throws BankException {
		Assert.assertNotNull(customerDao.inFundTransfer(10022, 10001, 4000));
	}

	@Test
	public void testInsertPayee() throws BankException {
		Assert.assertNotNull(customerDao.insertPayee(10001, 10002, "munna"));
	}

	@Test
	public void testOutFundTransfer() throws BankException {
		Assert.assertNotNull(customerDao.outFundTransfer(10002, 10001, "abc", 6000));
	}

	@Test
	public void testGenerateCheque() throws BankException {
		Assert.assertNotNull(customerDao.generateCheque(10001));
	}

	@Test
	public void testTrackStatus() throws BankException {
		Assert.assertNotNull(customerDao.trackStatus(12));
	}

	@Test
	public void testViewPayee() throws BankException {
		Assert.assertNotNull(customerDao.viewPayee(10001));
	}

	@Test
	public void testUpdateLockStatus() throws BankException {
		Assert.assertTrue(customerDao.updateLockStatus(11));
	}

	@Test
	public void testValidateUserInt() throws BankException {
		Assert.assertNotNull(customerDao.validateUser(11));
	}

	@Test
	public void testGetLockStatus() throws BankException {
		Assert.assertNotNull(customerDao.getLockStatus(11));
	}

	@Test
	public void testGetSecretQuestion() throws BankException {
		Assert.assertNotNull(customerDao.getSecretQuestion(11));
	}

	@Test
	public void testChangePasswordIntString() throws BankException {
		Assert.assertNotNull(customerDao.changePassword(11, "abc"));
	}

}
