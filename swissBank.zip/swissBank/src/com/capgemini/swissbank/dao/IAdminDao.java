package com.capgemini.swissbank.dao;

import java.util.List;

import com.capgemini.swissbank.bean.AccMasterBean;
import com.capgemini.swissbank.bean.CustomerBean;
import com.capgemini.swissbank.bean.TransactionBean;
import com.capgemini.swissbank.bean.UserTable;
import com.capgemini.swissbank.exception.BankException;

public interface IAdminDao {
	public UserTable createUser(AccMasterBean accMasterBean,CustomerBean customerBean)throws BankException;
	public List<TransactionBean> getTransactions(int choice)throws BankException;
	
}
