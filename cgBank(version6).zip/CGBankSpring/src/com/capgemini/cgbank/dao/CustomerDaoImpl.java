package com.capgemini.cgbank.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.capgemini.cgbank.bean.ServiceTrackerBean;
import com.capgemini.cgbank.bean.UserTable;
import com.capgemini.cgbank.exception.BankException;
@Repository
@Transactional
public class CustomerDaoImpl implements ICustomerDao{

	@PersistenceContext
	EntityManager entityManager;

	@Override
	public UserTable getValidUser(int userId, String password)
			throws BankException {
			
		UserTable user=null;
	
		try {
			TypedQuery<UserTable> qry1=entityManager.createQuery(IQueryMapperCustomer.viewUser, UserTable.class);
			
			qry1.setParameter(1, userId);
			qry1.setParameter(2, password);
			java.util.List<UserTable> list=qry1.getResultList();
			for (UserTable userTable : list) {
				user=userTable;
			}
			
		} catch (Exception e) {
			throw new BankException(e.getMessage());
		}
		return user;
		
	}

	@Override
	public int generateCheque(int accountId) throws BankException {
		
		int records=0;
		int id=0;
		try {
			Query qry1=entityManager.createQuery(IQueryMapperCustomer.INSERTSERVICETRACKER);
			
			qry1.setParameter(1, "NEW CHEQUE");
			qry1.setParameter(2, accountId);
			qry1.setParameter(3, "OPEN");
			records=qry1.executeUpdate();
			
			if(records>0)
			{
				TypedQuery<Integer> qry2=entityManager.createQuery(IQueryMapperCustomer.GETREQUISITIONID,Integer.class);
				id=qry2.executeUpdate();
			}
		} catch (Exception e) {
			throw new BankException("Some Error Occured. Cheque Book Generation Application Is Not Be Submitted.");
		}
		
		return id;
	}

	@Override
	public String trackStatus(int requisitionId) throws BankException {

		String status=null;
		ServiceTrackerBean serviceTracker;
		try {
			serviceTracker=entityManager.find(ServiceTrackerBean.class, requisitionId);
			status=serviceTracker.getStatus();
		} catch (Exception e) {
			throw new BankException("Invalid requisition Id.");
		}
		return status;
	}
	
	

}
