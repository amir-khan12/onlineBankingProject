package com.capgemini.cgbank.dao;

public interface IQueryMapperCustomer {

	
	public static final String viewUser="from UserTable where userId=? and password=?";
	
	public static final String INSERTSERVICETRACKER ="INSERT INTO SERVICE_TRACKER VALUES(serviceid_seq.NEXTVAL,?,?,SYSDATE,?)";
	
	public static final String GETREQUISITIONID="SELECT SERVICEID FROM SERVICE_TRACKER WHERE ACCOUNTID=?";
	
	public static final String GETSTATUS="SELECT SERVICESTATUS FROM SERVICE_TRACKER WHERE SERVICEID=?";
	
}
