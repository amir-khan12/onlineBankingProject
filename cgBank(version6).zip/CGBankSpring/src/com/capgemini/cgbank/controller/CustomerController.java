package com.capgemini.cgbank.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.capgemini.cgbank.bean.UserTable;
import com.capgemini.cgbank.exception.BankException;
import com.capgemini.cgbank.service.ICustomerService;

@Controller
public class CustomerController {
	static int loginAtempt=0;
	
	@Autowired
	ICustomerService customerService;
	
	 
	
	@RequestMapping("/home")
	public String showHomePage(){
		return ("home");
	}
	
	@RequestMapping("/validateLogin")
	public ModelAndView validateLogin(@RequestParam("userId") int userId,@RequestParam("password")String password){
		ModelAndView model=new ModelAndView();
		try {
			UserTable user=customerService.getValidUser(userId, password);
			if(user==null){
				loginAtempt++;
				if(loginAtempt<3){
				model.setViewName("home");
				
				String userInvalidmsg="Invalid User Id or Password";
				model.addObject("message", userInvalidmsg);
				}
				else
				{
					//lock account in db
					
					model.setViewName("home");
					
					String userInvalidmsg="You have entered wrong credentials 3 times.\nYour account is Locked'\n Contact the bank.";
					model.addObject("message", userInvalidmsg);
				}
				
			}
			else if(user.getLockStatus()!="l"){
				model.setViewName("userMenu");
				model.addObject("user", user);
			}
			else
			{
				model.setViewName("home");
				
				String userInvalidmsg="Sorry this account has been locked.\n Please contact the bank";
				model.addObject("message", userInvalidmsg);
			}
		} catch (BankException e) {
			model.setViewName("error");
			model.addObject("errorMessage",e.getMessage());
		}
		
		
		return model;
	}
	
}
