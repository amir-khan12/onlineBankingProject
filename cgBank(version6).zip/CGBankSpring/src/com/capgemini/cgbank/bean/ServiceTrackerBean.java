package com.capgemini.cgbank.bean;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
@Entity
@Table(name="ServiceTracker")
public class ServiceTrackerBean {
	@Id
	@Column(name="serviceId")
	private int serviceId;
	@Column(name="serviceDescription")
	private String serviceDesc;
	@Column(name="Serviceraiseddate")
	private Date serviceRaisedDate;
	@Column(name="status")
	private String status;
	@OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "accountId")
	private AccMasterBean account;
	public ServiceTrackerBean() {
		super();
	}
	
	public int getServiceId() {
		return serviceId;
	}
	public void setServiceId(int serviceId) {
		this.serviceId = serviceId;
	}
	public String getServiceDesc() {
		return serviceDesc;
	}
	public void setServiceDesc(String serviceDesc) {
		this.serviceDesc = serviceDesc;
	}
	
	public Date getServiceRaisedDate() {
		return serviceRaisedDate;
	}
	public void setServiceRaisedDate(Date serviceRaisedDate) {
		this.serviceRaisedDate = serviceRaisedDate;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}

	public AccMasterBean getAccount() {
		return account;
	}

	public void setAccount(AccMasterBean account) {
		this.account = account;
	}

	public ServiceTrackerBean(int serviceId, String serviceDesc,
			Date serviceRaisedDate, String status, AccMasterBean account) {
		super();
		this.serviceId = serviceId;
		this.serviceDesc = serviceDesc;
		this.serviceRaisedDate = serviceRaisedDate;
		this.status = status;
		this.account = account;
	}

	@Override
	public String toString() {
		return "ServiceTrackerBean [serviceId=" + serviceId + ", serviceDesc="
				+ serviceDesc + ", serviceRaisedDate=" + serviceRaisedDate
				+ ", status=" + status + ", account=" + account + "]";
	}
	
	
	


}
