package com.capgemini.cgbank.bean;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name="AccountMaster")
public class AccMasterBean {
	@Id
	@Column(name="accountId")
	private int accId;
	@Column(name="type")
	private String type;
	@Column(name="balance")
	private double accBalance;
	@Column(name="openDate")
	@Temporal(TemporalType.DATE)
	private Date openDate;
	public AccMasterBean() {
		super();
	}
	
	public int getAccId() {
		return accId;
	}
	public void setAccId(int accId) {
		this.accId = accId;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public double getAccBalance() {
		return accBalance;
	}
	public void setAccBalance(double accBalance) {
		this.accBalance = accBalance;
	}

	public Date getOpenDate() {
		return openDate;
	}

	public void setOpenDate(Date openDate) {
		this.openDate = openDate;
	}
	
	

	public AccMasterBean(int accId, String type, double accBalance,
			Date openDate) {
		super();
		this.accId = accId;
		this.type = type;
		this.accBalance = accBalance;
		this.openDate = openDate;
	}

	@Override
	public String toString() {
		return "AccMasterBean [accId=" + accId + ", type=" + type
				+ ", accBalance=" + accBalance + ", openDate=" + openDate
				+ "]";
	}
	
	
	

}
