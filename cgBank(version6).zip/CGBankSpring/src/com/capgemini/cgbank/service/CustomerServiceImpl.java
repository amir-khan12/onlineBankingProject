package com.capgemini.cgbank.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.cgbank.bean.UserTable;
import com.capgemini.cgbank.dao.ICustomerDao;
import com.capgemini.cgbank.exception.BankException;
@Service
public class CustomerServiceImpl implements ICustomerService {

	@Autowired
	ICustomerDao customerDao;
	@Override
	public UserTable getValidUser(int userId, String password)
			throws BankException {
		
		return customerDao.getValidUser(userId, password);
	}
	@Override
	public int generateCheque(int accountId) throws BankException {
		
		return customerDao.generateCheque(accountId);
	}
	@Override
	public String trackStatus(int requisitionId) throws BankException {
		
		return customerDao.trackStatus(requisitionId);
	}

}
