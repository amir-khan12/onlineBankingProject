package com.capgemini.swissbank.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import com.capgemini.swissbank.bean.TransactionBean;
import com.capgemini.swissbank.bean.UserTable;
import com.capgemini.swissbank.exception.BankException;
import com.capgemini.swissbank.util.DBConnection;


public class CustomerDaoImpl implements ICustomerDao {

	@Override
	public UserTable validateUser(int userId, String password)
			throws BankException {
		
		return null;
	}

	@Override
	public List<TransactionBean> viewMiniStatement(int accountId)
			throws BankException {
		
			int transactionNumber=0;
		List<TransactionBean> transactionList=new ArrayList<TransactionBean>();
		try{Connection conn=DBConnection.getInstance().getConnection();
		
		ResultSet rs=null;
		PreparedStatement preparedStatement=null;
				
		
			
			preparedStatement=conn.prepareStatement(QueryMapperCustomer.VIEWMINISTATEMENT);
			rs=preparedStatement.executeQuery();
			
			while(rs.next())
			{
				TransactionBean bean=new TransactionBean();
				bean.setAccId(rs.getInt(1));
				bean.setDateOfTrans(rs.getDate(2));
				bean.setTransDescription(rs.getString(3));
				bean.setTransId(rs.getInt(4));
				bean.setTransType(rs.getString(5));
				bean.setTransactionAmount(rs.getDouble(6));
				
				transactionList.add(bean);
				transactionNumber++;
			
			}
		} catch(SQLException sqlEx)
		{
			throw new BankException(sqlEx.getMessage());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			throw new BankException(e.getMessage());
		}	
		if(transactionNumber == 0)
			return null;
		else
			return transactionList;
		
	}

	@Override
	public List<TransactionBean> viewDetailedStatement(int accountId)
			throws BankException {

		int transactionNumber=0;
	List<TransactionBean> transactionList=new ArrayList<TransactionBean>();
	try{Connection conn=DBConnection.getInstance().getConnection();
	
	ResultSet rs=null;
	PreparedStatement preparedStatement=null;
			
	
		
		preparedStatement=conn.prepareStatement(QueryMapperCustomer.VIEWDETAILEDSTATEMENT);
		rs=preparedStatement.executeQuery();
		
		while(rs.next())
		{
			TransactionBean bean=new TransactionBean();
			bean.setAccId(rs.getInt(1));
			bean.setDateOfTrans(rs.getDate(2));
			bean.setTransDescription(rs.getString(3));
			bean.setTransId(rs.getInt(4));
			bean.setTransType(rs.getString(5));
			bean.setTransactionAmount(rs.getDouble(6));
			
			transactionList.add(bean);
			transactionNumber++;
		
		}
	} catch(SQLException sqlEx)
	{
		throw new BankException(sqlEx.getMessage());
	} catch (Exception e) {
		// TODO Auto-generated catch block
		throw new BankException(e.getMessage());
	}	
	if(transactionNumber == 0)
		return null;
	else
		return transactionList;
	}

	@Override
	public boolean changePassword(int accountId, String oldPassword,
			String newPassword) throws BankException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean changeAddress(int accountId, String address)
			throws BankException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean changePhoneNumber(int accountId, String phoneNumber)
			throws BankException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean inFundTransfer(int accountIdTo, int accountIdFrom,float transactionAmount)
			throws BankException {
		boolean isInserted=false;
		try{
					
			Connection conn = DBConnection.getInstance().getConnection();			
			PreparedStatement preparedStatement=
					conn.prepareStatement(QueryMapperCustomer.GETBALANCE);
			preparedStatement.setInt(1, accountIdFrom);
			
			ResultSet records = preparedStatement.executeQuery();
			
			if (records.next()) {
				float balance=records.getFloat(1);
				if(balance>=transactionAmount)
				{
					preparedStatement=conn.prepareStatement(QueryMapperCustomer.INSERTTRANSACTION);
					preparedStatement.setString(1, "FundTransfer");
					preparedStatement.setDate(2, Date.valueOf(LocalDate.now()));
					preparedStatement.setString(3, "debited");
					preparedStatement.setFloat(4, transactionAmount);
					preparedStatement.setInt(5, accountIdFrom);
					 int record=preparedStatement.executeUpdate();
					 if(record>0){
							preparedStatement=conn.prepareStatement(QueryMapperCustomer.UPDATEBALANCE);
							preparedStatement.setInt(2, accountIdFrom);
							preparedStatement.setFloat(1, balance-transactionAmount);
							if(preparedStatement.executeUpdate()>0){
								isInserted=true;
							}
						 }
					 
					 preparedStatement=conn.prepareStatement(QueryMapperCustomer.INSERTTRANSACTION);
						preparedStatement.setString(1, "FundTransfer");
						preparedStatement.setDate(2, Date.valueOf(LocalDate.now()));
						preparedStatement.setString(3, "credited");
						preparedStatement.setFloat(4, transactionAmount);
						preparedStatement.setInt(5, accountIdTo);
						  record=preparedStatement.executeUpdate();
						 if(record>0){
								preparedStatement=conn.prepareStatement(QueryMapperCustomer.UPDATEBALANCE);
								preparedStatement.setInt(2, accountIdTo);
								preparedStatement.setFloat(1, balance+transactionAmount);
								if(preparedStatement.executeUpdate()>0){
									isInserted=true;
								}
							 }
					
				}
			}
			
		}catch(SQLException sqlEx)
		{
			throw new BankException(sqlEx.getMessage());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			throw new BankException(e.getMessage());
		}		
		return isInserted;
	}

	@Override
	public boolean insertPayee(int accountId, int payeeAccountId,
			String nickName) throws BankException {
		boolean isInserted=false;
		try{
					
			Connection conn = DBConnection.getInstance().getConnection();			
			PreparedStatement preparedStatement=
					conn.prepareStatement(QueryMapperCustomer.INSERTPAYEE);
			preparedStatement.setInt(1, accountId);
			preparedStatement.setInt(2, payeeAccountId);
			preparedStatement.setString(3, nickName);
			int record=preparedStatement.executeUpdate();
			if(record>0)
				isInserted=true;
		}catch(SQLException sqlEx)
		{
			throw new BankException(sqlEx.getMessage());
		} catch (Exception e) {
			
			throw new BankException(e.getMessage());
		}
		return isInserted;
	}

	@Override
	public boolean outFundTransfer(int accountId, int payeeAccountId,
			String transactionPassword, float transactionAmount)
			throws BankException {
		boolean isInserted=false;
		try{
					
			Connection conn = DBConnection.getInstance().getConnection();			
			PreparedStatement preparedStatement=
					conn.prepareStatement(QueryMapperCustomer.GETBALANCE);
			preparedStatement.setInt(1, accountId);
			
			ResultSet records = preparedStatement.executeQuery();
			
			if (records.next()) {
				float balance=records.getFloat(1);
				if(balance>=transactionAmount)
				{
					preparedStatement=conn.prepareStatement(QueryMapperCustomer.INSERTTRANSACTION);
					preparedStatement.setString(1, "FundTransfer");
					preparedStatement.setDate(2, Date.valueOf(LocalDate.now()));
					preparedStatement.setString(3, "debited");
					preparedStatement.setFloat(4, transactionAmount);
					preparedStatement.setInt(5, accountId);
					 int record=preparedStatement.executeUpdate();
					 if(record>0){
							preparedStatement=conn.prepareStatement(QueryMapperCustomer.UPDATEBALANCE);
							preparedStatement.setInt(2, accountId);
							preparedStatement.setFloat(1, balance-transactionAmount);
							if(preparedStatement.executeUpdate()>0){
								isInserted=true;
							}
						 }
					 
				}
			}
			
		}catch(SQLException sqlEx)
		{
			throw new BankException(sqlEx.getMessage());
		} catch (Exception e) {
		
			throw new BankException(e.getMessage());
		}		
		
			
		
		return isInserted;
	}

	@Override
	public int generateCheque(int accountId) throws BankException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public String trackStatus(int requisitionId) throws BankException {
		// TODO Auto-generated method stub
		return null;
	}

}
