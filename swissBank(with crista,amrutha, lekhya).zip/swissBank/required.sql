create sequence transaction 
START with 100
INCREMENT BY 3

create sequence fundid_seq 
START with 1000
INCREMENT BY 1

create sequence accountid_seq 
START with 10000
INCREMENT BY 1


CREATE TABLE CUSTOMER(AccountID NUMBER(10) references account_master(accountid), customername VARCHAR2(50), Email VARCHAR2(30), Address VARCHAR2(100), Pancard VARCHAR2(15) primary key);

CREATE TABLE transcation 
  ( 
     transactionid     NUMBER PRIMARY KEY, 
     trandescription   VARCHAR2(100), 
     dateoftransaction DATE, 
     transactiontype   VARCHAR2(1), 
     tranamount        NUMBER(15), 
     accountid         NUMBER(10) REFERENCES account_master (accountid) 
  ); 



CREATE TABLE service_tracker 
  ( 
     serviceid          NUMBER PRIMARY KEY, 
     servicedescription VARCHAR2(100), 
     accountid          NUMBER REFERENCES account_master(accountid), 
     serviceraiseddate  DATE, 
     servicestatus      VARCHAR2(20) 
  ); 


CREATE TABLE user_table 
  ( 
     accountid           NUMBER REFERENCES account_master(accountid), 
     userid              NUMBER PRIMARY KEY, 
     loginpassword       VARCHAR2(15), 
     secretquestion      VARCHAR2(50), 
     transactionpassword VARCHAR2(15), 
     lockstatus          VARCHAR2(1) 
  );



CREATE TABLE payee_table 
  ( 
     accountid      NUMBER REFERENCES account_master(accountid), 
     payeeaccountid NUMBER PRIMARY KEY, 
     nickname       VARCHAR2(40) 
  ); 

CREATE TABLE fund_transfer 
  ( 
     fundtransferid NUMBER PRIMARY KEY, 
     accountid      NUMBER(10) REFERENCES account_master(accountid), 
     payeeaccountid NUMBER(10) REFERENCES payee_table(payeeaccountid), 
     dateoftransfer DATE, 
     transferamount NUMBER(15) 
  ); 

alter table user_table add type char;

ALTER TABLE CUSTOMER ADD phoneNumber varchar2(12);

create sequence userid_seq 
START with 10
INCREMENT BY 1

create sequence serviceid_seq 
START with 10
INCREMENT BY 2

CREATE TABLE ACCOUNT_MASTER(AccountID NUMBER(10) primary key, AccountType VARCHAR2(25),
AccountBalance NUMBER(15) ,OpenDate DATE);






