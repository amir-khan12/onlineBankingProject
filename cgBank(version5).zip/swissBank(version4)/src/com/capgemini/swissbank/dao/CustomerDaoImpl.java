package com.capgemini.swissbank.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import com.capgemini.swissbank.bean.PayeeBean;
import com.capgemini.swissbank.bean.TransactionBean;
import com.capgemini.swissbank.bean.UserTable;
import com.capgemini.swissbank.exception.BankException;
import com.capgemini.swissbank.util.DBConnection;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;


public class CustomerDaoImpl implements ICustomerDao {

	Logger logger=Logger.getRootLogger();
	
	
	public CustomerDaoImpl() {
		PropertyConfigurator.configure("resources//log4j.properties");
	}

	@Override
	public UserTable validateUser(int userId, String password)
			throws BankException {
		 
		UserTable user= null;
		try{
					
			Connection conn = DBConnection.getInstance().getConnection();			
			PreparedStatement preparedStatement=
					conn.prepareStatement(IQueryMapperCustomer.viewUser);
			preparedStatement.setInt(1, userId);		
			preparedStatement.setString(2, password);
			ResultSet rs=preparedStatement.executeQuery();
			
			
				
			
			if(rs.next()){			
				user=new UserTable();
				
				user.setAccId(rs.getInt("accountid"));
				
				user.setUserId(rs.getInt("userid"));
				
				user.setPassword(rs.getString("loginpassword"));
				
				user.setSecretQue(rs.getString("secretquestion"));
				
				user.setSecretAns(rs.getString("secretanswer"));
			
				user.setTransPassword(rs.getString("transactionpassword"));
			
				user.setLockStatus(rs.getString("lockstatus"));	
				
				user.setType(rs.getString("type"));
			
				
			}
			else{
				
				return null;
			}
			
					if(user.getType().equals("A")){
							user.setUserName("Admin");			
							}
						else{
				
			preparedStatement=
					conn.prepareStatement(IQueryMapperCustomer.GETCUSTOMERNAME);
			preparedStatement.setInt(1, user.getAccId());
		
			rs=preparedStatement.executeQuery();
			
			while(rs.next()){
				user.setUserName(rs.getString("CUSTOMERNAME"));		
			
					}
			}
			
		}catch(SQLException sqlEx)
		{
			logger.error(sqlEx.getMessage());
			throw new BankException(sqlEx.getMessage());
		} catch (Exception e) {	
			logger.error(e.getMessage());
			throw new BankException(e.getMessage());
			}
		return user;			
		
	}

	@Override
	public List<TransactionBean> viewMiniStatement(int accountId)
			throws BankException {
		
			int transactionNumber=0;
		List<TransactionBean> transactionList=new ArrayList<TransactionBean>();
		try{
			Connection conn=DBConnection.getInstance().getConnection();
		
		ResultSet rs=null;
		PreparedStatement preparedStatement=null;
				
		
			
			preparedStatement=conn.prepareStatement(IQueryMapperCustomer.VIEWMINISTATEMENT);
			preparedStatement.setInt(1, accountId);
			rs=preparedStatement.executeQuery();
			
			while(rs.next())
			{
				
				TransactionBean bean=new TransactionBean();
				bean.setTransId(rs.getInt(1));
				bean.setTransDescription(rs.getString(2));
				bean.setDateOfTrans(rs.getDate(3));
				
				bean.setTransType(rs.getString(4));
				
				bean.setTransactionAmount(rs.getDouble(5));
				
				bean.setAccId(rs.getInt(6));
			
			
				
				transactionList.add(bean);
				transactionNumber++;
			}
		} catch(SQLException sqlEx)
		{
			logger.error(sqlEx.getMessage());
			throw new BankException(sqlEx.getMessage());
		} catch (Exception e) {
			logger.error(e.getMessage());
			throw new BankException(e.getMessage());
		}	
		if(transactionNumber == 0)
			return null;
		else
			return transactionList;
		
	}

	@Override
	public List<TransactionBean> viewDetailedStatement(int accountId)
			throws BankException {

		int transactionNumber=0;
	List<TransactionBean> transactionList=new ArrayList<TransactionBean>();
	try{Connection conn=DBConnection.getInstance().getConnection();
	
	ResultSet rs=null;
	PreparedStatement preparedStatement=null;
			
	
		
		preparedStatement=conn.prepareStatement(IQueryMapperCustomer.VIEWDETAILEDSTATEMENT);
		preparedStatement.setInt(1, accountId);
		rs=preparedStatement.executeQuery();
		
		while(rs.next())
		{
			TransactionBean bean=new TransactionBean();
			bean.setTransId(rs.getInt(1));
			bean.setTransDescription(rs.getString(2));
			bean.setDateOfTrans(rs.getDate(3));
			
			bean.setTransType(rs.getString(4));
			
			bean.setTransactionAmount(rs.getDouble(5));
			
			bean.setAccId(rs.getInt(6));
			
			transactionList.add(bean);
			transactionNumber++;
		
		}
	} catch(SQLException sqlEx)
	{
		logger.error(sqlEx.getMessage());
		throw new BankException(sqlEx.getMessage());
	} catch (Exception e) {
		logger.error(e.getMessage());
		throw new BankException(e.getMessage());
	}	
	if(transactionNumber == 0)
		return null;
	else
		return transactionList;
	}

	@Override
	public boolean changePassword(int accountId, String oldPassword,
			String newPassword) throws BankException {
		try{
			
			Connection conn = DBConnection.getInstance().getConnection();			
			PreparedStatement preparedStatement=
					conn.prepareStatement(IQueryMapperCustomer.CHANGEPASSWORD);
			preparedStatement.setInt(2, accountId);
			preparedStatement.setString(3, oldPassword);
			preparedStatement.setString(1,newPassword);
			int records = preparedStatement.executeUpdate();
			
			if (records>0) {
				return true;
			}
			else
				return false;
		}catch(SQLException sqlEx)
		{
			logger.error(sqlEx.getMessage());
			throw new BankException(sqlEx.getMessage());
		} catch (Exception e) {
			logger.error(e.getMessage());
			throw new BankException(e.getMessage());
		}
	}

	@Override
	public boolean changeAddress(int accountId, String address)
			throws BankException {
	
		try{
					
			Connection conn = DBConnection.getInstance().getConnection();			
			PreparedStatement preparedStatement=
					conn.prepareStatement(IQueryMapperCustomer.CHANGEADDRESS);
			preparedStatement.setInt(2, accountId);
			preparedStatement.setString(1, address);
			int records = preparedStatement.executeUpdate();
			
			if (records>0) {
				return true;
			}
			else
				return false;
		}catch(SQLException sqlEx)
		{
			logger.error(sqlEx.getMessage());
			throw new BankException(sqlEx.getMessage());
		} catch (Exception e) {
			logger.error(e.getMessage());
			throw new BankException(e.getMessage());
		}	
			
	}

	@Override
	public boolean changePhoneNumber(int accountId, String phoneNumber)
			throws BankException {
		try{
			
			Connection conn = DBConnection.getInstance().getConnection();			
			PreparedStatement preparedStatement=
					conn.prepareStatement(IQueryMapperCustomer.CHANGEPHONENUMBER);
			preparedStatement.setInt(2, accountId);
			preparedStatement.setString(1, phoneNumber);
			int records = preparedStatement.executeUpdate();
			
			if (records>0) {
				return true;
			}
			else
				return false;
		}catch(SQLException sqlEx)
		{
			logger.error(sqlEx.getMessage());
			throw new BankException(sqlEx.getMessage());
		} catch (Exception e) {
			logger.error(e.getMessage());
			throw new BankException(e.getMessage());
		}
	}

	@Override
	public double inFundTransfer(int accountIdTo, int accountIdFrom,double transactionAmount)
			throws BankException {
		
		boolean isInserted=false;
		double balance=0;
		try{
					
			Connection conn = DBConnection.getInstance().getConnection();			
			PreparedStatement preparedStatement=
					conn.prepareStatement(IQueryMapperCustomer.GETBALANCE);
			preparedStatement.setInt(1, accountIdFrom);
			
			ResultSet records = preparedStatement.executeQuery();
			
			if (records.next()) {
				 balance=records.getDouble(1);
				if(balance>=transactionAmount)
				{
					preparedStatement=conn.prepareStatement(IQueryMapperCustomer.INSERTTRANSACTION);
					preparedStatement.setString(1, "FundTransfer");
					preparedStatement.setDate(2, Date.valueOf(LocalDate.now()));
					preparedStatement.setString(3, "debited");
					preparedStatement.setDouble(4, transactionAmount);
					preparedStatement.setInt(5, accountIdFrom);
					 int record=preparedStatement.executeUpdate();
					 if(record>0){
							preparedStatement=conn.prepareStatement(IQueryMapperCustomer.UPDATEBALANCE);
							preparedStatement.setInt(2, accountIdFrom);
							preparedStatement.setDouble(1, balance-transactionAmount);
							if(preparedStatement.executeUpdate()>0){
								isInserted=true;
								balance=balance-transactionAmount;
							}
						 }
					 
					 preparedStatement=conn.prepareStatement(IQueryMapperCustomer.INSERTTRANSACTION);
						preparedStatement.setString(1, "FundTransfer");
						preparedStatement.setDate(2, Date.valueOf(LocalDate.now()));
						preparedStatement.setString(3, "credited");
						preparedStatement.setDouble(4, transactionAmount);
						preparedStatement.setInt(5, accountIdTo);
						  record=preparedStatement.executeUpdate();
						 if(record>0){
							 preparedStatement=
										conn.prepareStatement(IQueryMapperCustomer.GETBALANCE);
								preparedStatement.setInt(1, accountIdTo);
								
								 records = preparedStatement.executeQuery();
								 float balance1=0;
								if (records.next()) {
									  balance1=records.getFloat(1);}
								preparedStatement=conn.prepareStatement(IQueryMapperCustomer.UPDATEBALANCE);
								preparedStatement.setInt(2, accountIdTo);
								preparedStatement.setDouble(1, balance1+transactionAmount);
								if(preparedStatement.executeUpdate()>0){
									isInserted=true;
								}
							 }
					
				}else{
					throw new BankException("Insufficient Balance");
				}
			}
			
		}catch(SQLException sqlEx)
		{
			logger.error(sqlEx.getMessage());
			throw new BankException(sqlEx.getMessage());
		} catch (Exception e) {
			logger.error(e.getMessage());
			throw new BankException(e.getMessage());
		}		
		return balance;
	}

	@Override
	public boolean insertPayee(int accountId, int payeeAccountId,
			String nickName) throws BankException {
		boolean isInserted=false;
		try{
					
			Connection conn = DBConnection.getInstance().getConnection();			
			PreparedStatement preparedStatement=
					conn.prepareStatement(IQueryMapperCustomer.INSERTPAYEE);
			preparedStatement.setInt(1, accountId);
			preparedStatement.setInt(2, payeeAccountId);
			preparedStatement.setString(3, nickName);
			int record=preparedStatement.executeUpdate();
			if(record>0)
				isInserted=true;
		}catch(SQLException sqlEx)
		{
			logger.error(sqlEx.getMessage());
			throw new BankException(sqlEx.getMessage());
		} catch (Exception e) {
			logger.error(e.getMessage());
			throw new BankException(e.getMessage());
		}
		return isInserted;
	}

	@Override
	public double outFundTransfer(int accountId, int payeeAccountId,
			String transactionPassword,double transactionAmount)
			throws BankException {
		boolean isInserted=false;
		double balance=0;
		try{
					
			Connection conn = DBConnection.getInstance().getConnection();			
			PreparedStatement preparedStatement=
					conn.prepareStatement(IQueryMapperCustomer.GETBALANCE);
			preparedStatement.setInt(1, accountId);
			
			ResultSet records = preparedStatement.executeQuery();
			
			if (records.next()) {
				 balance=records.getDouble(1);
				if(balance>=transactionAmount)
				{
					preparedStatement=conn.prepareStatement(IQueryMapperCustomer.INSERTTRANSACTION);
					preparedStatement.setString(1, "FundTransfer");
					preparedStatement.setDate(2, Date.valueOf(LocalDate.now()));
					preparedStatement.setString(3, "debited");
					preparedStatement.setDouble(4, transactionAmount);
					preparedStatement.setInt(5, accountId);
					 int record=preparedStatement.executeUpdate();
					 if(record>0){
							preparedStatement=conn.prepareStatement(IQueryMapperCustomer.UPDATEBALANCE);
							preparedStatement.setInt(2, accountId);
							preparedStatement.setDouble(1, balance-transactionAmount);
							if(preparedStatement.executeUpdate()>0){
								isInserted=true;
								if(isInserted){
									balance=balance-transactionAmount;
								}
							}
						 }
					 
				}else{
					throw new BankException("Insufficient Balance");
				}
			}
			
		}catch(SQLException sqlEx)
		{
			logger.error(sqlEx.getMessage());
			throw new BankException(sqlEx.getMessage());
		} catch (Exception e) {
			logger.error(e.getMessage());
			throw new BankException(e.getMessage());
		}		
		
			
		
		return balance;
	}

	@Override
	public int generateCheque(int accountId) throws BankException {
	
	int serviceId =0;
	try{
			
			Connection conn = DBConnection.getInstance().getConnection();			
			PreparedStatement preparedStatement=
					conn.prepareStatement(IQueryMapperCustomer.INSERTSERVICETRACKER);
			preparedStatement.setString(1, "NEW CHEQUE");
			preparedStatement.setInt(2, accountId);
		
			preparedStatement.setString(3, "OPEN");
			
			int records = preparedStatement.executeUpdate();
		
			
			if (records>0) {
				preparedStatement=conn.prepareStatement(IQueryMapperCustomer.GETREQUISITIONID);
				preparedStatement.setInt(1, accountId);
				 ResultSet list=preparedStatement.executeQuery();
				 while(list.next()){
					 serviceId=list.getInt(1);
				 }
				
			}
			else{
				throw new BankException("Unable to process the request");
			}
				
		}catch(SQLException sqlEx)
		{
			logger.error(sqlEx.getMessage());
			throw new BankException(sqlEx.getMessage());
		} catch (Exception e) {
				logger.error(e.getMessage());
				throw new BankException(e.getMessage());
		}
	return serviceId;
	}

	@Override
	public String trackStatus(int requisitionId) throws BankException {
		
		String status=null;
		ResultSet resultSet=null;
	 
		
		try{
					
			Connection conn = DBConnection.getInstance().getConnection();			
			PreparedStatement preparedStatement=conn.prepareStatement(IQueryMapperCustomer.GETSTATUS);
			preparedStatement.setInt(1, requisitionId);
		
			 resultSet = preparedStatement.executeQuery();
			
			if (resultSet.next()) {
			    
			    status=resultSet.getString(1);
			    return status;
			}	
		
			else
			{
				throw new BankException("Invalid requisition Id");
			}
			
		}catch(SQLException sqlEx)
		{
			logger.error(sqlEx.getMessage());
			throw new BankException(sqlEx.getMessage());
		} catch (Exception e) {
			logger.error(e.getMessage());
			throw new BankException(e.getMessage());
		}		
		
		
	}
	
	
	
	
	
	
	
	
	@Override
	public List<PayeeBean> viewPayee(int accountId)
			throws BankException {
		
			int payeeNumber=0;
		List<PayeeBean> payeeList=new ArrayList<PayeeBean>();
		try{
			Connection conn=DBConnection.getInstance().getConnection();
		
		ResultSet rs=null;
		PreparedStatement preparedStatement=null;
				
		
			
			preparedStatement=conn.prepareStatement(IQueryMapperCustomer.VIEWALLPAYEE);
			preparedStatement.setInt(1, accountId);
			rs=preparedStatement.executeQuery();
			
		
			while(rs.next())
			{
				PayeeBean bean=new PayeeBean();
				bean.setPayeeAccId(rs.getInt(2));
				bean.setAccountId(rs.getInt(1));
				bean.setNickName(rs.getString(3));
				
				
				
				payeeList.add(bean);
				payeeNumber++;
					}
		} catch(SQLException sqlEx)
		{
			throw new BankException(sqlEx.getMessage());
		} catch (Exception e) {
			logger.error(e.getMessage());
			throw new BankException(e.getMessage());
		}	
		if(payeeNumber == 0)
			return null;
		else
			return payeeList;
		
	}

	@Override
	public boolean updateLockStatus(int userId) throws BankException {
		try{
			
			Connection conn = DBConnection.getInstance().getConnection();			
			PreparedStatement preparedStatement=
					conn.prepareStatement(IQueryMapperCustomer.SETLOCKSTATUS);
			preparedStatement.setInt(2, userId);
			preparedStatement.setString(1, "l");
			int records = preparedStatement.executeUpdate();
			
			if (records>0) {
				return true;
			}
			else
				return false;
		}catch(SQLException sqlEx)
		{
			logger.error(sqlEx.getMessage());
			throw new BankException(sqlEx.getMessage());
		} catch (Exception e) {
			logger.error(e.getMessage());
			throw new BankException(e.getMessage());
		}	
		
	}

	@Override
	public UserTable validateUser(int userId) throws BankException {
		UserTable user=new UserTable();
		try{
					
			Connection conn = DBConnection.getInstance().getConnection();			
			PreparedStatement preparedStatement=
					conn.prepareStatement(IQueryMapperCustomer.GETUSER);
			preparedStatement.setInt(1, userId);		
		
			ResultSet list=preparedStatement.executeQuery();
			if(list==null){
				return null;
			}
			else{
			while(list.next()){				
				user.setAccId(list.getInt("accountid"));
				user.setUserId(list.getInt("userid"));
				user.setPassword(list.getString("loginpassword"));
				user.setTransPassword(list.getString("transactionpassword"));
				user.setType(list.getString("type"));
				user.setSecretQue(list.getString("secretquestion"));
				user.setLockStatus(list.getString("lockstatus"));				
			}
			
			if(user.getType().equals("A")){
				user.setUserName("Admin");
			
			}
			else{
				
			preparedStatement=
					conn.prepareStatement(IQueryMapperCustomer.GETCUSTOMERNAME);
			preparedStatement.setInt(1, user.getAccId());
		
			list=preparedStatement.executeQuery();
		
			while(list.next()){
				user.setUserName(list.getString("CUSTOMERNAME"));
				
			}
			}
			}
		}catch(SQLException sqlEx)
		{
			logger.error(sqlEx.getMessage());
			throw new BankException(sqlEx.getMessage());
		} catch (Exception e) {
			logger.error(e.getMessage());
			throw new BankException(e.getMessage());
		}
		return user;		
	}

	@Override
	public String getLockStatus(int userId) throws BankException {
		String stauts=null;
		try{
			
			Connection conn = DBConnection.getInstance().getConnection();			
			PreparedStatement preparedStatement=
					conn.prepareStatement(IQueryMapperCustomer.GETLOCKSTATUS);
			preparedStatement.setInt(1, userId);		
		
			ResultSet rs=preparedStatement.executeQuery();
		
			while(rs.next()){	
				stauts=rs.getString(1);
			}
				
		}catch(SQLException sqlEx)
		{
			logger.error(sqlEx.getMessage());
			throw new BankException(sqlEx.getMessage());
		} catch (Exception e) {
			logger.error(e.getMessage());
			throw new BankException(e.getMessage());
		}
		return stauts;
	}

	@Override
	public String[] getSecretQuestion(int userId) throws BankException {
		String[] secret = new String[2];
		try{
			
			Connection conn = DBConnection.getInstance().getConnection();			
			PreparedStatement preparedStatement=
					conn.prepareStatement(IQueryMapperCustomer.GETSECRETQUESTION);
			preparedStatement.setInt(1, userId);		
		
			ResultSet rs=preparedStatement.executeQuery();
		
			while(rs.next()){	
				secret[0]=rs.getString(1);
				secret[1]=rs.getString(2);
			}
				
		}catch(SQLException sqlEx)
		{
			logger.error(sqlEx.getMessage());
			throw new BankException(sqlEx.getMessage());
		} catch (Exception e) {
			logger.error(e.getMessage());
			throw new BankException(e.getMessage());
		}
		
		
		return secret;
	}

	@Override
	public boolean changePassword(int userId, String newPassword)
			throws BankException {
try{
			
			Connection conn = DBConnection.getInstance().getConnection();			
			PreparedStatement preparedStatement=
					conn.prepareStatement(IQueryMapperCustomer.RESETPASSWORD);
			preparedStatement.setInt(2, userId);
			
			preparedStatement.setString(1,newPassword);
			int records = preparedStatement.executeUpdate();
			
			if (records>0) {
				return true;
			}
			else
				return false;
		}catch(SQLException sqlEx)
		{
			logger.error(sqlEx.getMessage());
			throw new BankException(sqlEx.getMessage());
		} catch (Exception e) {
			logger.error(e.getMessage());
			throw new BankException(e.getMessage());
		}
	}
	
	
	
	

}
