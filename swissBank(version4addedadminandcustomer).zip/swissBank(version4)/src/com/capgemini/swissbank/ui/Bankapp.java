package com.capgemini.swissbank.ui;

import java.util.List;
import java.util.Scanner;

import com.capgemini.swissbank.bean.AccMasterBean;
import com.capgemini.swissbank.bean.AccountType;
import com.capgemini.swissbank.bean.CustomerBean;
import com.capgemini.swissbank.bean.PayeeBean;
import com.capgemini.swissbank.bean.TransactionBean;
import com.capgemini.swissbank.bean.UserTable;
import com.capgemini.swissbank.exception.BankException;
import com.capgemini.swissbank.service.AdminServiceImpl;
import com.capgemini.swissbank.service.CustomerServiceImpl;




public class Bankapp {
	public static Scanner in=new Scanner(System.in);
	
	public static void main(String[] args) {
		
		int uid;
		String password;
		UserTable validUser = null;
		boolean userCheck = false;
		boolean isOpen=false;
		char uType;
		int count=0;
		CustomerServiceImpl serviceCustomer = new CustomerServiceImpl();

		//Scanner input = new Scanner(System.in);

		System.out.println(
				"-------------------------------------------------------------------------------------------------");
		System.out.println("                                  WELCOME                    ");
		System.out.println(
				"-------------------------------------------------------------------------------------------------");

		do {
			
			System.out.println("Enter user id:");
			uid = in.nextInt();
			in.nextLine();			
			
			try {
		
				boolean isValid=serviceCustomer.validateUser(uid);
				if(isValid){
					 isOpen=serviceCustomer.getUserStatus(uid);
					if(isOpen){
						do{
							
							System.out.println("Enter password:(Forgot  password?(press \"Y\"))");
							password = in.nextLine();
							//if user forgets password
									if(password.equalsIgnoreCase("Y"))
									{
										String[] secret=serviceCustomer.getSecretQuestion(uid);
										System.out.println("Answer the secret question\n"+secret[0]);
										String secretAnswer = in.nextLine();
							
										if(secretAnswer.equals(secret[1]))
										{
											serviceCustomer.changePassword(uid, "sbq500#");
											System.out.println("Your password is sbq500#\nUse this to login.\nChange your password on next login");
											
										}
										
										else{
											try {
												serviceCustomer.updateLockStatus(uid);
												System.out.println("Your answer is wrong.\nSeems like an illegal access......... Your account has been locked\nContact the Admin");
												System.exit(-1);	
											} catch (BankException e) {
									
												e.printStackTrace();
											}
											
										}
										
										}
									else{
								
									validUser=serviceCustomer.validateUser(uid, password);
										if (validUser != null) {
											
											userCheck = true;
										
											}
						
									else {
										
										count++;
							
										if(count<3&&count>0){
											System.out.println("Incorrect password entered "+(3-count)+" tries left ");
										}
										else{
											try {
												serviceCustomer.updateLockStatus(uid);
												System.out.println("Sorry Your account got locked\nContact the Admin");
												System.exit(-1);	
											} catch (BankException e) {
									
												e.printStackTrace();
											}
												
											}							
							
										}
						
								}
						}while(count<3&&userCheck==false);
							
						
						
					}
					else{
						System.out.println("Sorry Your account is locked.\nContact Admin");
						System.exit(-1);
					}
				}
				else{
					System.out.println("Invalid User ID");
				}
				
			} catch (BankException e) {
				
				e.printStackTrace();
			}
			
		} while (userCheck == false);

		
		if (validUser.getType().equals("A")) {
			openAdminPage(validUser); // opens admin page
		} else {
			openUserPage(validUser); // opens customer page
		}
		

	}

	private static void openAdminPage(UserTable admin) {
int choice = 0;
		
		System.out.println("welcome  bank" + admin.getUserName() );
		System.out.println("what would you like to do today?");
		
		do {
			System.out.println("1. create account");
			System.out.println("2. view transactions");
			System.out.println("3. exit");
			
			switch (choice) {
			case 1:
				createAccount(admin);
				break;

			case 2:
				viewTransactions(admin);				
			
			default:
				System.out.println("wrong option entered please try again");
				break;
			}
		} while (choice !=3 );

	}
	
	private static void openUserPage(UserTable user) {
		int selection = 0;
		                               
		System.out.println("welcome " + user.getUserName() + " please enter your choice");
		
		//Scanner input1 = new Scanner(System.in);
		do {
			// some cosmetics to be done here
			System.out.println("1. View Bank statement");
			System.out.println("2. Change password");
			System.out.println("3. Change address and/or phone number");
			System.out.println("4. Fund transfer");
			System.out.println("5. Issue new cheque");
			System.out.println("6. track chequebook/card  delivery status");
			System.out.println("7. exit");

			selection = in.nextInt();
			in.nextLine();
			switch (selection) {
			case 1:
				System.out.println("here's your statement");
				showBankStatement(user);
				break;

			case 2:
				System.out.println("password changed");
				changePassword(user);
				break;

			case 3:
				System.out.println("address and phone number changed");
				changeDetails(user);
				break;

			case 4:
				System.out.println("fund transferred to blah");
				fundTransfer(user);
				break;

			case 5:
				System.out.println("new cheque");
				newChequeBook(user);
				break;

			case 6:
				
				trackStatus(user);
				break;

			case 7:
				System.out.println("Thank you have a nice day :-)");
				break;

			default:
				System.out.println("Invalid option");
				break;
			}

		} while (selection != 7);

		//input1.close();
	}
	
	

	private static void showBankStatement(UserTable user) {
		int choice = 0;
		//Scanner sc = new Scanner(System.in);

		do {
			System.out.println("1. mini bank statement");
			System.out.println("2. detailed statement");

			choice = in.nextInt();

			switch (choice) {
			case 1:
				miniBankStatement(user);
				break;

			case 2:
				detailedBankStatement(user);
				break;

			default:
				System.out.println("invalid option!!!");
				System.out.println("please try again");
				break;
			}
		} while (choice != 1 && choice != 2);
		//sc.close();

	}
	
	private static void miniBankStatement(UserTable user) {

		CustomerServiceImpl serviceCustomer = new CustomerServiceImpl();

		int accId = user.getAccId();

		List<TransactionBean> list = null;
		try {
			list = serviceCustomer.viewMiniStatement(accId);
		} catch (BankException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		for (TransactionBean transactionBean : list) {
			System.out.println(transactionBean);

		}
	}
	
	private static void detailedBankStatement(UserTable user) {
		
		CustomerServiceImpl serviceCustomer = new CustomerServiceImpl();
		int accId = user.getAccId();
		
		List<TransactionBean> list = null;
		try {
			list = serviceCustomer.viewDetailedStatement(accId);
		} catch (BankException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		for (TransactionBean transactionBean : list) {
			System.out.println(transactionBean);
		}
	}

	private static void changePassword(UserTable user) {
		
		int accId = user.getAccId();
		String checkOldPwd = user.getPassword();
		String checkNewPwd;
		String oldPwd;
		String newPwd;
		boolean changeStatus = false;

		CustomerServiceImpl serviceCustomer = new CustomerServiceImpl();

		//Scanner sc1 = new Scanner(System.in);

		System.out.println("Enter your current password");
		oldPwd = in.nextLine();

		// compare if he's entered his old pwd right
		// this validation should be performed in the service layer

		Out:
		if (checkOldPwd.equals(oldPwd)) {
			System.out.println("Enter your new password");
			newPwd = in.nextLine();
			
			do {
				System.out.println("Reenter your new password");
				checkNewPwd = in.nextLine();
				
				if(!(newPwd.equals(checkNewPwd))) {
					System.out.println("passwords don't match!!! ");
					System.out.println("please check and try again");
				}
				
			} while (!(newPwd.equals(checkNewPwd)));
			
			System.out.println("Are you sure, you made up your mind???");
			
			String answer=in.nextLine();
			
			if(answer.equals("Y")||answer.equals("y"))
			{	
				try {
					changeStatus = serviceCustomer.changePassword(accId, oldPwd, newPwd);
				} catch (BankException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			
				if (changeStatus) {
					System.out.println("Password successfully changed");

				} else {
					System.out.println("Unable to change password");

				}
			}else
				break Out;

		} else {
			System.out.println("unable to proceed further as wrong password is entered");
		}
		//sc1.close();
	}

	private static void changeDetails(UserTable user) {
		int choice = 0;
		//Scanner sc2 = new Scanner(System.in);

		do {
			System.out.println("1. change address");
			System.out.println("2. change phone number");

			choice = in.nextInt();
			in.nextLine();
			switch (choice) {
			case 1:
				changeAddress(user);	

				break;

			case 2:
				changePhoneNumber(user);				
				break;
				
			default:
				System.out.println("invalid option!!!");
				System.out.println("please try again");
				break;
			}

		}			
		while (choice != 1 && choice != 2);
		
		//sc2.close();
	}
	
	private static void changeAddress(UserTable user) {
		int accId = user.getAccId();
		String newAddress;
		boolean isChanged = false;
		
		CustomerServiceImpl serviceCustomer = new CustomerServiceImpl();
		
		
		//Scanner sc = new Scanner(System.in);
		System.out.println("please enter your new address");
		newAddress = in.nextLine();
		
		try {
			isChanged = serviceCustomer.changeAddress(accId, newAddress);
		} catch (BankException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		if(isChanged) {
			System.out.println("New address updated successfully");
		}else {
			System.out.println("could not update the address");
		}
		
		//sc.close();
	}

	private static void changePhoneNumber(UserTable user) {
		int accId = user.getAccId();
		String newPhoneNumber;
		boolean isChanged = false;
		
		CustomerServiceImpl serviceCustomer = new CustomerServiceImpl();
		
		//Scanner sc = new Scanner(System.in);
		
		System.out.println("please enter your new Phone number");
		newPhoneNumber = in.nextLine();
		
		try {
			isChanged = serviceCustomer.changePhoneNumber(accId, newPhoneNumber);
		} catch (BankException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		if(isChanged) {
			System.out.println("New phone number updated successfully");
		}else {
			System.out.println("could not update the phone number");
		}
		
		//sc.close();		
	}

	private static void fundTransfer(UserTable user) {
		CustomerServiceImpl serviceCustomer = new CustomerServiceImpl();
		System.out.println("1.With in the same Bank");
		System.out.println("2.External Banks");
		int choice=in.nextInt();
		in.nextLine();
		switch (choice) {
		case 1:
			inFundTransfer(user);
			break;
		case 2:
			System.out.println("1.Add Payee");
			System.out.println("2.Select Payee");
			int key=in.nextInt();
			in.nextLine();
			switch (key) {
			case 1:
				System.out.println("Enter Payee Account Id:");
				int payeeAccountId=in.nextInt();
				in.nextLine();
				System.out.println("Enter Payee Nickname:");
				String nickName=in.nextLine();
				try {
					boolean isInserted=serviceCustomer.insertPayee(user.getAccId(), payeeAccountId, nickName);
					if(isInserted)
						System.out.println("Payee added successfully.");
				} catch (BankException e) {
					
					e.printStackTrace();
				}
				break;
			case 2:
				
				System.out.println("The list of payees registered are:");
				try {
					List<PayeeBean> payeeList=serviceCustomer.viewPayee(user.getAccId());
					
					for (PayeeBean payeeBean : payeeList) {
						System.out.println(payeeBean);
					}
					
					System.out.println("Enter Transaction password");
					String transactionPassword=in.nextLine();
					if(serviceCustomer.validateTransactionPassword(transactionPassword, user))
					{
						System.out.println("Enter payee AccountID");
						int payeeAccountNumber=in.nextInt();
						in.nextLine();
					System.out.println("Enter amount");
					double transactionAmount=in.nextDouble();
					in.nextLine();
					if(serviceCustomer.validateTransactionAmount(transactionAmount)){
					double balance=serviceCustomer.outFundTransfer(user.getAccId(), payeeAccountNumber, transactionPassword, transactionAmount);
					System.out.println("Transaction successful\nyour current balance is "+balance);
					}
					else{
						System.out.println("Can not transact more than 1000000");
					}
					}
					else{
						System.out.println("Invalid Transaction password");
					}
				} catch (BankException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				break;
			default:
				break;
			}
			
			
			break;
		default:
			break;
		}
		
		
	}
	
	private static void newChequeBook(UserTable user)  {
		CustomerServiceImpl serviceCustomer = new CustomerServiceImpl();
		try {
			int requisitionId=serviceCustomer.generateCheque(user.getAccId());
			System.out.println("Your requisition id is"+requisitionId);
		} catch (BankException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	private static void trackStatus(UserTable user) {
		CustomerServiceImpl serviceCustomer = new CustomerServiceImpl();
		System.out.println("Enter the requisition Id");
		int requisitionId=in.nextInt();
		in.nextLine();
		try {
			String status=serviceCustomer.trackStatus(requisitionId);
			System.out.println("Your status is "+status);
		} catch (BankException e) {
			
			e.printStackTrace();
		}
		
	}
	
	private static void inFundTransfer(UserTable user){
		CustomerServiceImpl serviceCustomer = new CustomerServiceImpl();
		System.out.println("Enter payee Account Id");
		int accountIdTo=in.nextInt();
		in.nextLine();
		System.out.println("Enter Transaction amount");
		double transactionAmount=in.nextDouble();			
		in.nextLine();
		try {
			double balance=serviceCustomer.inFundTransfer(accountIdTo, user.getAccId(), transactionAmount);
			System.out.println("Transaction is successful\nYour Balance is "+balance);
		} catch (BankException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
private static void createAccount(UserTable admin){
		
		CustomerBean newCustomer = new CustomerBean() ; 
		AccMasterBean masterSheet = new AccMasterBean();
		AdminServiceImpl serviceAdmin = new AdminServiceImpl();
		UserTable newValidCustomer = new UserTable();
		String addLine1;
		String addLine2;
		String addLine3;
		List<String> errorList = null;
		
		do {
			errorList = null;// check to done here if empty or null
			System.out.println("please enter the following details to create the account");
			System.out.println("enter the name of the customer");
			newCustomer.setCustomerName(in.nextLine());
			System.out.println("Enter the address (line 1)"); // sad part is that address is in one line
			addLine1 = in.nextLine();
			System.out.println("enter the adress (line 2)");
			addLine2 = in.nextLine();
			System.out.println("enter the address (line 3)");
			addLine3 = in.nextLine();
			newCustomer.setAddress(addLine1 + "\n" + addLine2 + "\n" + addLine3);
			System.out.println("enter phone number");
			newCustomer.setPhoneNumber(in.nextLine());
			System.out.println("enter emailId");
			newCustomer.setEmail(in.nextLine());
			System.out.println("enter the type of account (savings/current)");
			// do cross check this statement later
			masterSheet.setType(AccountType.valueOf(in.nextLine()));
			System.out.println("enter the opening balance.");
			System.out.println(" minimum balance = 3000 Rs");
			masterSheet.setAccBalance(in.nextDouble());
			in.nextLine();
			// pan number details not entered
			errorList = serviceAdmin.isValidNewCustomer(newCustomer, masterSheet);
			if (!errorList.isEmpty()) {
				System.out.println("Customer details entered are not valid");
				System.out.println("please refer the errors and reenter the details ");
				for (String errors : errorList) {
					System.out.println(errors);
				}
			} 
		} while (!errorList.isEmpty());
		
		try {
			newValidCustomer = serviceAdmin.createUser(masterSheet, newCustomer);
			System.out.println("congrats new user created");
			System.out.println("account number : " + newValidCustomer.getAccId());
			System.out.println("account name :" + newCustomer.getCustomerName());
			// why the heck should admin know dummy password?
			// to do generate password of 8 characters write a seperate method
			System.out.println(" dummy password has been sent to " + newCustomer.getPhoneNumber());
			System.out.println("account created successfully!!!");
		} catch (BankException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	private static void viewTransactions(UserTable admin){
		int choice = 0;
		AdminServiceImpl serviceAdmin = new AdminServiceImpl();
		List<TransactionBean> list = null;
		
		do {
			System.out.println("Enter the type of transactions to be viewed");
			System.out.println("1. daily transction");
			System.out.println("2. weekly transaction");
			System.out.println("3. monthly transcations");
			choice = in.nextInt();
			in.nextLine();
			switch (choice) {
			case 1:
				try {
					list = serviceAdmin.getTransactionsDaily();
					for (TransactionBean transactionBean : list) {
						System.out.println(transactionBean);
					}
				} catch (BankException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				break;
			case 2:
				try {
					list = serviceAdmin.getTransactionsWeekly();
					for (TransactionBean transactionBean : list) {
						System.out.println(transactionBean);
					}
				} catch (BankException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				break;
			case 3:
				try {
					list = serviceAdmin.getTransactionsMonthly();
					for (TransactionBean transactionBean : list) {
						System.out.println(transactionBean);
					}
				} catch (BankException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				break;

			default:
				System.out.println("wrong option entered please try again");
				break;
			}
		} while (choice!=1 || choice!=2 || choice!=3);
	}

}
